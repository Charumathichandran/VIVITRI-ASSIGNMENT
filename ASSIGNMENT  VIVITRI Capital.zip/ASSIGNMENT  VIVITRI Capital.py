#!/usr/bin/env python
# coding: utf-8

# ### 1. Question:
# Write a program to compute the frequency of the words from the input. The output should output
# after sorting the key alphanumerically.

# In[1]:


d=dict()
s=input("Enter the string:")
for i in s.split():
    d[i]=d.get(i,0)+1
for i,j in d.items():
    print(i,end=":")
    print(j)


# ### 2. Question:
# A website requires the users to input username and password to register. Write a program
# to check the validity of password input by users.

# In[2]:


s=input("enter sequence of comma separated passwords :")
import re
l=s.split(",")
for i in l:
    if(len(i)>=6 and len(i)<=12):
        if re.search("([a-z])+", i):
            if re.search("([A-Z])+", i):
                if re.search("([0-9])+", i):
                    if re.search("([#,@,$])+", i):
                        print(i)


# ### 3. Question:
# Write a program which takes 2 digits, X,Y as input and generates a 2-dimensional array. The
# element value in the i-th row and j-th column of the array should be i*j.

# In[3]:


row_num = int(input("Input number of rows: "))
col_num = int(input("Input number of columns: "))
multi_list = [[0 for col in range(col_num)] for row in range(row_num)]

for row in range(row_num):
    for col in range(col_num):
        multi_list[row][col]= row*col

print(multi_list)


# In[4]:


row_num = int(input("Input number of rows: "))
col_num = int(input("Input number of columns: "))
multi_list = [[0 for col in range(col_num)] for row in range(row_num)]

for row in range(row_num):
    for col in range(col_num):
        multi_list[row][col]= row*col

print(multi_list)


# 4. Finding words which are greater than given length k We will take a string of words from the user along with an integer k. We will find all words whose length is greater than k.

# In[5]:


def string_k(k, str):
    string = []
    text = str.split(" ")
    for x in text:
        if len(x) > k:
            string.append(x)
    return "," . join(string)
k=6
str ="learn programming at include help"
print(string_k(k, str))


#  5. Convert a String to camelCase in Python (Without using any string functions[capitalize()..etc],Use ASCII Values)

# In[8]:


from re import sub
def camel_case(s):
    s = sub(r"(_|-)+", " ", s).title().replace(" ", "")
    return ''.join([s[0].lower(), s[1:]])
print(camel_case('Hello world'))


# 6. Find uncommon words from two string We will take two strings as input from users consisting of words. And then we will print all words from the string that are not present in both the strings.

# In[9]:


str1 = "learn programming at includehelp".split(" ")
str2 = "learn python programming language".split(" ")
s=[]
for i in str1:
    if i not in str2:
        s.append(i)
for i in str2:
    if i not in str1:
        s.append(i)
print(s)
        


# ### 9.Pattern Printing:

# In[27]:


n=6
for i in range(0, n):
    for j in range(0, i+1):
        print("* ",end="")
    print("\r")
print()
for i in range(n+1, 1,-1):
    for j in range(i-1, 0,-1):
        print("* ",end="")
    print("\r")

